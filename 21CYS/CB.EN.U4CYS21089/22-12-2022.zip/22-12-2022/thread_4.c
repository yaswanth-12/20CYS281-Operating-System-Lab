#include <pthread.h>
#include <stdlib.h>
#include <stdio.h> 
#include <unistd.h>

struct number {
    int a;
    int b;
};

void *addition (void *s){

    // struct number *z = (struct number *)s; || this is type casting ||
    struct number *z = s;
    printf("Adding %d and %d gives %d\n",z->a,z->b,z->a + z->b);
}

int main(){

    int result;
    pthread_t threads[3];
    struct number k[3];
    for ( int i = 0; i < 3; i++ ){
        scanf("%d", &k[i].a);
        scanf("%d", &k[i].b);
        result = pthread_create(&threads[i], NULL, addition, (void *) &k[i]);
        // result = pthread_create(&threads[i], NULL, (void *)addition,  &k[i]);

        if (result) {
      
         printf("Error in creating thread, %d ", result);
         exit(-1);
      }
    }
    pthread_exit(NULL);
}